import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BatsManComponent } from './bats-man.component';

describe('BatsManComponent', () => {
  let component: BatsManComponent;
  let fixture: ComponentFixture<BatsManComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BatsManComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BatsManComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
