import { Component, OnInit,SimpleChanges,OnChanges } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { Observable ,Subject} from 'rxjs';
import { takeUntil,pairwise } from 'rxjs/operators';
@Component({
  selector: 'app-bats-man',
  templateUrl: './bats-man.component.html',
  styleUrls: ['./bats-man.component.css']
})
export class BatsManComponent implements OnInit {
  constructor(private fb: FormBuilder) {
     
  }
  profileForm:FormGroup;
  submitted = false;
  propChanges:any;
  destroy$ = new Subject();
   colorIndex:number;
  ngOnInit() {
    this.profileForm = this.fb.group({
      grandtotal: [''],
      batsman: new FormArray([])
    });
    this.onChangeTickets();
    this.handleFormChanges();
  }
  get f() { return this.profileForm.controls; }
  get t() { return this.f.batsman as FormArray; }
  get batsmanFormGroups() { return this.t.controls as FormGroup[]; } 

  onChangeTickets() {
    const numberOfTickets = 8;
    if (this.t.length < numberOfTickets) {
        for (let i = this.t.length; i < numberOfTickets; i++) {
            this.t.push(this.fb.group({
              batsmanruns: ['0'],
              batsmantotal: ['0']
            }));
        }
    } else {
        for (let i = this.t.length; i >= numberOfTickets; i--) {
            this.t.removeAt(i);
        }
    }

}


  handleFormChanges() {
    
    this.profileForm.get("batsman").valueChanges.pipe(pairwise()).subscribe(([prev, next]: [any, any])=>{
     // console.log("PREV1", prev);
     // console.log("NEXT1", next);
     let finalV=0;
      let prevbatsmanrunArr=[];
      let nextbatsmanrunArr=[];
      let grantTotalArr=[];
      for (let i = 0; i < prev.length; i++) {
        prevbatsmanrunArr[i]=prev[i].batsmanruns.split(",");
      }
      for (let i = 0; i < next.length; i++) {
        nextbatsmanrunArr[i]=next[i].batsmanruns.split(",");
    
        let total=nextbatsmanrunArr[i].reduce((prev,next)=>prev+(+next),0);
        next[i].batsmantotal=total;
        this.profileForm.get("batsman").setValue(next,{emitEvent: false});
        grantTotalArr[i]=total;
      
      }
      let Grandtotal=grantTotalArr.reduce((prev,next)=>prev+(+next),0);

 this.profileForm.get("grandtotal").setValue(Grandtotal,{emitEvent: false});
 

      let resPrev=[];
      let resNext=[];
      //console.log(JSON.stringify(nextbatsmanrunArr));
      for(let i=0;i<nextbatsmanrunArr.length; i++){
        for( let j=0;j<nextbatsmanrunArr[i].length;j++){
            if(nextbatsmanrunArr[i][j]=="4" && nextbatsmanrunArr[i][j+1]=="6" || nextbatsmanrunArr[i][j]=="6" && nextbatsmanrunArr[i][j+1]=="4"){
                resNext[i]=i;
                //console.log(i);
        
            }
        }
        for( let j=0;j<prevbatsmanrunArr[i].length;j++){
          if(prevbatsmanrunArr[i][j]=="4" && prevbatsmanrunArr[i][j+1]=="6" || prevbatsmanrunArr[i][j]=="6" && prevbatsmanrunArr[i][j+1]=="4"){
              resPrev[i]=i;
              
      
          }
      }
       
    }
//  console.log(resNext)
  var array3 = resNext.filter(function(obj) { return resPrev.indexOf(obj) == -1; });
  
  if (array3.length!=0)
  {
this.colorIndex=array3[0];
  } 
    
    })
    
   /* 
    this.profileForm.get("batsman").valueChanges.pipe(pairwise()).subscribe((user: any) => {
      let grantTotalArr=[];
      let batsmanrunArr=[];
for (let i = 0; i < user.length; i++) {
    let total=user[i].batsmanruns.split(",").reduce((prev,next)=>prev+(+next),0);
    user[i].batsmantotal=total;
    this.profileForm.get("batsman").setValue(user,{emitEvent: false});
    grantTotalArr[i]=total;
    //this.profileForm.get('batsman').updateValueAndValidity();
     batsmanrunArr[i]=user[i].batsmanruns.split(",");
   console.log(batsmanrunArr);
    
}
 
let Grandtotal=grantTotalArr.reduce((prev,next)=>prev+(+next),0);

 this.profileForm.get("grandtotal").setValue(Grandtotal,{emitEvent: false});
 

   });*/
   
  }
  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
}