import { Directive, HostListener, ElementRef} from '@angular/core';

@Directive({
  selector: '[appNumberCommaVal]'
})
export class NumberCommaValDirective {

  constructor(private el: ElementRef) { }
  private regex: RegExp = new RegExp(/^[0-9]{1,10}(,[0-9]{0,1})*$/);//[0-9]{2,3}[,]{0,1} /^[,0-9]*$/
  private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', 'ArrowLeft', 'ArrowRight', 'Del', 'Delete'];
  
  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if (this.specialKeys.indexOf(event.key) !== -1) {
      return;
    }
    const current: string = this.el.nativeElement.value;
    const next: string = current.concat(event.key);
    if (next && !String(next).match(this.regex)) {
      event.preventDefault();
    }
  }

}
