import { NumberCommaValDirective } from './number-comma-val.directive';

describe('NumberCommaValDirective', () => {
  it('should create an instance', () => {
    const directive = new NumberCommaValDirective();
    expect(directive).toBeTruthy();
  });
});
